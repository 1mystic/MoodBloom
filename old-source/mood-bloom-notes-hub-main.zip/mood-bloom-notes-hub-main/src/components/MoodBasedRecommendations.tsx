
import React from 'react';
import { Card } from '@/components/ui/card';
import { ExternalLink } from 'lucide-react';
import { Note } from './NoteCard';
import { Link } from 'react-router-dom';

interface Resource {
  id: string;
  title: string;
  url: string;
  resource_type: string;
  description: string;
}

interface MoodBasedRecommendationsProps {
  mood: string;
  recommendedNotes: Note[];
  recommendedResources: Resource[];
}

const MoodBasedRecommendations: React.FC<MoodBasedRecommendationsProps> = ({ 
  mood, 
  recommendedNotes, 
  recommendedResources 
}) => {
  const getMoodMessage = (mood: string) => {
    switch (mood) {
      case 'happy':
        return "Embrace your joy with these positive recommendations!";
      case 'calm':
        return "Maintain your peaceful state with these serene picks.";
      case 'energetic':
        return "Channel your energy into these productive suggestions!";
      case 'focused':
        return "Stay in the zone with these concentration-enhancing resources.";
      case 'creative':
        return "Feed your imagination with these inspiring selections!";
      case 'reflective':
        return "Deepen your introspection with these thoughtful recommendations.";
      default:
        return "Discover personalized content based on your current mood.";
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Recommendations for your {mood} mood</h2>
      <p className="text-muted-foreground">{getMoodMessage(mood)}</p>
      
      {recommendedNotes.length > 0 && (
        <div>
          <h3 className="text-lg font-medium mb-2">Notes you might want to revisit</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {recommendedNotes.slice(0, 4).map(note => (
              <Link to={`/edit/${note.id}`} key={note.id} className="no-underline">
                <Card className="p-3 border hover:border-primary transition-colors">
                  <h4 className="font-medium">{note.title}</h4>
                  <p className="text-sm text-muted-foreground line-clamp-2">{note.content}</p>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      )}
      
      {recommendedResources.length > 0 && (
        <div>
          <h3 className="text-lg font-medium mb-2">Web resources for you</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {recommendedResources.slice(0, 4).map(resource => (
              <a 
                key={resource.id} 
                href={resource.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="no-underline"
              >
                <Card className="p-3 border hover:border-primary transition-colors">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium">{resource.title}</h4>
                    <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <span className="text-xs text-primary inline-block mb-1">
                    {resource.resource_type}
                  </span>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {resource.description}
                  </p>
                </Card>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default MoodBasedRecommendations;
