
import React from 'react';
import { Sun, CloudSun, Zap, Target, Lightbulb, Moon } from 'lucide-react';

interface MoodSelectorProps {
  onMoodSelect: (mood: string) => void;
  currentMood: string;
}

const moods = [
  { id: 'happy', label: 'Happy', icon: <Sun className="h-4 w-4 mr-2" /> },
  { id: 'calm', label: 'Calm', icon: <CloudSun className="h-4 w-4 mr-2" /> },
  { id: 'energetic', label: 'Energetic', icon: <Zap className="h-4 w-4 mr-2" /> },
  { id: 'focused', label: 'Focused', icon: <Target className="h-4 w-4 mr-2" /> },
  { id: 'creative', label: 'Creative', icon: <Lightbulb className="h-4 w-4 mr-2" /> },
  { id: 'reflective', label: 'Reflective', icon: <Moon className="h-4 w-4 mr-2" /> },
];

const MoodSelector: React.FC<MoodSelectorProps> = ({ onMoodSelect, currentMood }) => {
  return (
    <div className="w-full">
      <h2 className="text-lg font-semibold mb-3">How are you feeling today?</h2>
      <div className="flex flex-wrap gap-2">
        {moods.map((mood) => (
          <button
            key={mood.id}
            onClick={() => onMoodSelect(mood.id)}
            className={`mood-chip flex items-center mood-${mood.id} ${
              currentMood === mood.id ? 'ring-2 ring-primary' : ''
            }`}
          >
            {mood.icon}
            {mood.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default MoodSelector;
