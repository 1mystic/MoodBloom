
import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Pencil, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';

export interface Note {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  createdAt: string;
}

interface NoteCardProps {
  note: Note;
  onDelete: (id: string) => void;
}

const NoteCard: React.FC<NoteCardProps> = ({ note, onDelete }) => {
  const truncateContent = (content: string, maxLength: number = 150) => {
    if (content.length <= maxLength) return content;
    return content.slice(0, maxLength) + '...';
  };

  return (
    <Card className="note-card">
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-lg font-semibold">{note.title}</h3>
        <div className="flex gap-1">
          <Link to={`/edit/${note.id}`}>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Pencil className="h-4 w-4" />
            </Button>
          </Link>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 text-destructive"
            onClick={() => onDelete(note.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div className="mb-3">
        <span className="text-xs text-muted-foreground">
          {new Date(note.createdAt).toLocaleDateString()}
        </span>
        <span className="ml-2 px-2 py-1 rounded-full bg-secondary/10 text-xs font-medium">
          {note.category}
        </span>
      </div>
      
      <p className="text-sm text-muted-foreground mb-3">
        {truncateContent(note.content)}
      </p>
      
      <div className="flex flex-wrap gap-1 mt-2">
        {note.tags.map((tag, index) => (
          <span 
            key={index} 
            className="tag bg-primary/20 text-primary-foreground"
          >
            #{tag}
          </span>
        ))}
      </div>
    </Card>
  );
};

export default NoteCard;
