
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import NoteForm from '../components/NoteForm';
import { createNote } from '../services/noteService';
import { toast } from 'sonner';

const CreateNotePage = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSaveNote = async (note: { title: string; content: string; tags: string[] }) => {
    setIsSubmitting(true);
    try {
      const result = await createNote(note);
      
      if (result) {
        toast("Note created successfully!");
        navigate('/notes');
      } else {
        toast("Failed to create note");
      }
    } catch (error) {
      console.error("Error creating note:", error);
      toast("Failed to create note");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        <h1 className="text-3xl font-bold mb-6">Create New Note</h1>
        
        <div className="max-w-2xl mx-auto">
          <NoteForm onSave={handleSaveNote} isSubmitting={isSubmitting} />
        </div>
      </main>
    </div>
  );
};

export default CreateNotePage;
