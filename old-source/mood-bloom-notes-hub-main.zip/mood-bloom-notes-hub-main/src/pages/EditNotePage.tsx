
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import NoteForm from '../components/NoteForm';
import { getNoteById, updateNote } from '../services/noteService';
import { toast } from 'sonner';

const EditNotePage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [initialNote, setInitialNote] = useState<{
    id?: string;
    title: string;
    content: string;
    tags: string[];
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const loadNote = async () => {
      if (!id) {
        toast("Note ID not provided");
        navigate('/notes');
        return;
      }

      try {
        const note = await getNoteById(id);
        
        if (note) {
          setInitialNote({
            id: note.id,
            title: note.title,
            content: note.content,
            tags: note.tags
          });
        } else {
          toast("Note not found");
          navigate('/notes');
        }
      } catch (error) {
        console.error("Error loading note:", error);
        toast("Failed to load note");
        navigate('/notes');
      } finally {
        setIsLoading(false);
      }
    };

    loadNote();
  }, [id, navigate]);

  const handleSaveNote = async (note: { title: string; content: string; tags: string[] }) => {
    if (!id) return;
    
    setIsSubmitting(true);
    try {
      const result = await updateNote(id, note);
      
      if (result) {
        toast("Note updated successfully!");
        navigate('/notes');
      } else {
        toast("Failed to update note");
      }
    } catch (error) {
      console.error("Error updating note:", error);
      toast("Failed to update note");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container py-8 text-center">
          <p className="text-muted-foreground">Loading note...</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        <h1 className="text-3xl font-bold mb-6">Edit Note</h1>
        
        <div className="max-w-2xl mx-auto">
          {initialNote && (
            <NoteForm 
              initialNote={initialNote} 
              onSave={handleSaveNote}
              isSubmitting={isSubmitting}
            />
          )}
        </div>
      </main>
    </div>
  );
};

export default EditNotePage;
