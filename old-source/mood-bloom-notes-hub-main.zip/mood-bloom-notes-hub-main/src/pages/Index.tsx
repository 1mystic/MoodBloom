
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import MoodSelector from '../components/MoodSelector';
import MoodBasedRecommendations from '../components/MoodBasedRecommendations';
import { getRecommendationsForMood } from '../services/noteService';
import { toast } from 'sonner';

const Index = () => {
  const [currentMood, setCurrentMood] = useState('happy');
  const [recommendations, setRecommendations] = useState({
    notes: [],
    resources: []
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Get mood-based recommendations
    const fetchRecommendations = async () => {
      setIsLoading(true);
      try {
        const moodRecs = await getRecommendationsForMood(currentMood);
        setRecommendations(moodRecs);
      } catch (error) {
        console.error("Error fetching recommendations:", error);
        toast("Failed to load recommendations");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchRecommendations();
  }, [currentMood]);

  const handleMoodSelect = (mood: string) => {
    setCurrentMood(mood);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        <div className={`p-6 rounded-lg mb-8 bg-[hsl(var(--${currentMood}))/0.15]`}>
          <MoodSelector onMoodSelect={handleMoodSelect} currentMood={currentMood} />
        </div>
        
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading recommendations...</p>
          </div>
        ) : (
          <MoodBasedRecommendations
            mood={currentMood}
            recommendedNotes={recommendations.notes}
            recommendedResources={recommendations.resources}
          />
        )}
      </main>
    </div>
  );
};

export default Index;
