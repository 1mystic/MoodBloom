
import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import NoteCard, { Note } from '../components/NoteCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Link } from 'react-router-dom';
import { PlusCircle, Search } from 'lucide-react';
import { getAllNotes, deleteNote } from '../services/noteService';
import { useToast } from '@/hooks/use-toast';
import { toast } from 'sonner';

const NotesPage = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const { toast: useToastFn } = useToast();

  useEffect(() => {
    loadNotes();
  }, []);

  const loadNotes = async () => {
    setIsLoading(true);
    try {
      const allNotes = await getAllNotes();
      setNotes(allNotes);
    } catch (error) {
      console.error("Failed to load notes:", error);
      toast("Failed to load notes");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteNote = async (id: string) => {
    try {
      const result = await deleteNote(id);
      if (result) {
        useToastFn({
          title: "Note deleted",
          description: "Your note has been successfully removed"
        });
        await loadNotes();
      } else {
        useToastFn({
          title: "Error",
          description: "Failed to delete the note",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Error deleting note:", error);
      toast("Failed to delete note");
    }
  };

  // Get unique categories from notes
  const categories = ['All', ...new Set(notes.map(note => note.category))];

  // Filter notes based on search and category
  const filteredNotes = notes.filter(note => {
    const matchesSearch = searchTerm === '' || 
      note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === '' || selectedCategory === 'All' || 
      note.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <h1 className="text-3xl font-bold">My Notes</h1>
          <Link to="/create">
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" />
              Create New Note
            </Button>
          </Link>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search notes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category === 'All' ? '' : category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
        
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading notes...</p>
          </div>
        ) : filteredNotes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredNotes.map(note => (
              <NoteCard key={note.id} note={note} onDelete={handleDeleteNote} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium mb-2">No notes found</h3>
            <p className="text-muted-foreground mb-4">
              {searchTerm || selectedCategory ? 
                "Try adjusting your search or filter criteria." : 
                "Start creating notes to see them here."}
            </p>
            {!searchTerm && !selectedCategory && (
              <Link to="/create">
                <Button>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Create Your First Note
                </Button>
              </Link>
            )}
          </div>
        )}
      </main>
    </div>
  );
};

export default NotesPage;
