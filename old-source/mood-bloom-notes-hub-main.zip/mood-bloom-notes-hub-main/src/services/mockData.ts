
import { Note } from '../components/NoteCard';

export const mockNotes: Note[] = [
  {
    id: '1',
    title: 'My Meditation Journey',
    content: 'Today I tried a new meditation technique that really helped clear my mind. I focused on my breathing for 10 minutes and felt much more relaxed afterward.',
    category: 'Mindfulness',
    tags: ['meditation', 'calm', 'wellness'],
    createdAt: '2023-04-05T10:30:00Z'
  },
  {
    id: '2',
    title: 'Project Ideas for Work',
    content: 'Brainstorming session results: 1) Create a mood-based recommendation system, 2) Develop a time tracking tool with focus metrics, 3) Design a visual goal tracking dashboard.',
    category: 'Work',
    tags: ['productivity', 'projects', 'ideas'],
    createdAt: '2023-03-28T14:15:00Z'
  },
  {
    id: '3',
    title: 'Weekend Hiking Plans',
    content: 'Planning to hike the Eagle Mountain trail this weekend. Need to prepare: water bottle, trail mix, comfortable shoes, and map. Weather forecast looks good!',
    category: 'Outdoors',
    tags: ['hiking', 'weekend', 'activity'],
    createdAt: '2023-04-01T09:45:00Z'
  },
  {
    id: '4',
    title: 'Favorite Recipe: Pasta Primavera',
    content: 'Ingredients: pasta, bell peppers, zucchini, cherry tomatoes, garlic, olive oil, parmesan cheese. Cook pasta, sauté veggies, combine with pasta, add cheese. Simple and delicious!',
    category: 'Cooking',
    tags: ['recipe', 'food', 'healthy'],
    createdAt: '2023-03-15T18:20:00Z'
  },
  {
    id: '5',
    title: 'Book Reflections: Atomic Habits',
    content: 'Key takeaways: 1) Small changes lead to remarkable results, 2) Focus on systems not goals, 3) Identity-based habits stick better, 4) Environment design trumps motivation.',
    category: 'Reading',
    tags: ['books', 'productivity', 'habits'],
    createdAt: '2023-02-20T11:10:00Z'
  }
];

export const mockResources = [
  {
    id: '1',
    title: 'The Science of Happiness',
    url: 'https://example.com/happiness-science',
    type: 'article',
    description: 'Research-backed strategies to increase your daily happiness and well-being.',
    moods: ['happy', 'reflective']
  },
  {
    id: '2',
    title: 'Meditation for Beginners',
    url: 'https://example.com/meditation-beginners',
    type: 'video',
    description: 'A gentle introduction to meditation practices for stress reduction.',
    moods: ['calm', 'reflective']
  },
  {
    id: '3',
    title: '10 Morning Routines for High Energy',
    url: 'https://example.com/morning-routines',
    type: 'blog',
    description: 'Start your day with these energizing routines to maximize productivity.',
    moods: ['energetic', 'focused']
  },
  {
    id: '4',
    title: 'Deep Work: Rules for Focused Success',
    url: 'https://example.com/deep-work',
    type: 'article',
    description: 'How to cultivate intense focus in a distracted world.',
    moods: ['focused']
  },
  {
    id: '5',
    title: 'Creative Thinking Exercises',
    url: 'https://example.com/creative-thinking',
    type: 'blog',
    description: 'Unlock your creative potential with these mental exercises.',
    moods: ['creative']
  },
  {
    id: '6',
    title: 'Journal Prompts for Self-Discovery',
    url: 'https://example.com/journal-prompts',
    type: 'article',
    description: 'Thoughtful questions to deepen your self-understanding.',
    moods: ['reflective']
  },
  {
    id: '7',
    title: 'The Power of Positive Psychology',
    url: 'https://example.com/positive-psychology',
    type: 'blog',
    description: 'How focusing on strengths can lead to greater life satisfaction.',
    moods: ['happy', 'reflective']
  },
  {
    id: '8',
    title: 'Yoga Sequence for Inner Peace',
    url: 'https://example.com/yoga-peace',
    type: 'video',
    description: 'A gentle 15-minute yoga routine to center yourself.',
    moods: ['calm']
  },
  {
    id: '9',
    title: 'HIIT Workouts for Busy People',
    url: 'https://example.com/hiit-workouts',
    type: 'video',
    description: 'Quick, effective exercises to boost your energy and mood.',
    moods: ['energetic']
  },
  {
    id: '10',
    title: 'Productivity Systems Compared',
    url: 'https://example.com/productivity-systems',
    type: 'article',
    description: 'Find the right productivity approach for your working style.',
    moods: ['focused']
  }
];

// Helper function to get recommendations based on mood
export const getRecommendationsForMood = (mood: string) => {
  const relevantNotes = mockNotes.filter(note => {
    const moodCategories: Record<string, string[]> = {
      'happy': ['fun', 'happy', 'joy', 'positive'],
      'calm': ['meditation', 'calm', 'mindfulness', 'relaxation'],
      'energetic': ['exercise', 'outdoors', 'activity', 'workout'],
      'focused': ['work', 'study', 'productivity', 'focus'],
      'creative': ['art', 'ideas', 'creative', 'design'],
      'reflective': ['reading', 'journal', 'thinking', 'reflection']
    };
    
    // Check if any of the note tags match the mood categories
    return note.tags.some(tag => moodCategories[mood]?.includes(tag)) ||
           moodCategories[mood]?.some(keyword => 
             note.content.toLowerCase().includes(keyword) || 
             note.title.toLowerCase().includes(keyword)
           );
  });
  
  const relevantResources = mockResources.filter(resource => 
    resource.moods.includes(mood)
  );
  
  return {
    notes: relevantNotes,
    resources: relevantResources
  };
};
