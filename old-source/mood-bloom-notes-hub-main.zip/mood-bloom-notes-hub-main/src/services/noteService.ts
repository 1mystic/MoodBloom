
import { Note } from '../components/NoteCard';
import { supabase } from '../integrations/supabase/client';
import { toast } from 'sonner';

// Get all notes
export const getAllNotes = async (): Promise<Note[]> => {
  try {
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching notes:', error);
      toast("Failed to fetch notes");
      return [];
    }
    
    return data.map(note => ({
      id: note.id,
      title: note.title,
      content: note.content,
      category: note.category || 'Uncategorized',
      tags: note.tags || [],
      createdAt: note.created_at
    }));
  } catch (error) {
    console.error('Error in getAllNotes:', error);
    toast("Failed to fetch notes");
    return [];
  }
};

// Get a single note by ID
export const getNoteById = async (id: string): Promise<Note | undefined> => {
  try {
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      console.error('Error fetching note:', error);
      toast("Failed to fetch note");
      return undefined;
    }
    
    return {
      id: data.id,
      title: data.title,
      content: data.content,
      category: data.category || 'Uncategorized',
      tags: data.tags || [],
      createdAt: data.created_at
    };
  } catch (error) {
    console.error('Error in getNoteById:', error);
    toast("Failed to fetch note");
    return undefined;
  }
};

// Create a new note
export const createNote = async (note: Omit<Note, 'id' | 'category' | 'createdAt'>): Promise<Note | undefined> => {
  try {
    // Automatically categorize the note based on content and tags
    const category = categorizeNote(note.content, note.tags);
    
    const { data, error } = await supabase
      .from('notes')
      .insert([{
        title: note.title,
        content: note.content,
        tags: note.tags,
        category,
      }])
      .select()
      .single();
    
    if (error) {
      console.error('Error creating note:', error);
      toast("Failed to create note");
      return undefined;
    }
    
    return {
      id: data.id,
      title: data.title,
      content: data.content,
      category: data.category || 'Uncategorized',
      tags: data.tags || [],
      createdAt: data.created_at
    };
  } catch (error) {
    console.error('Error in createNote:', error);
    toast("Failed to create note");
    return undefined;
  }
};

// Update an existing note
export const updateNote = async (
  id: string, 
  updates: Pick<Note, 'title' | 'content' | 'tags'>
): Promise<Note | undefined> => {
  try {
    // Re-categorize based on new content and tags
    const category = categorizeNote(updates.content, updates.tags);
    
    const { data, error } = await supabase
      .from('notes')
      .update({
        title: updates.title,
        content: updates.content,
        tags: updates.tags,
        category,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error('Error updating note:', error);
      toast("Failed to update note");
      return undefined;
    }
    
    return {
      id: data.id,
      title: data.title,
      content: data.content,
      category: data.category || 'Uncategorized',
      tags: data.tags || [],
      createdAt: data.created_at
    };
  } catch (error) {
    console.error('Error in updateNote:', error);
    toast("Failed to update note");
    return undefined;
  }
};

// Delete a note
export const deleteNote = async (id: string): Promise<boolean> => {
  try {
    const { error } = await supabase
      .from('notes')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting note:', error);
      toast("Failed to delete note");
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error in deleteNote:', error);
    toast("Failed to delete note");
    return false;
  }
};

// Simple categorization logic (in real app, this could use AI)
const categorizeNote = (content: string, tags: string[]): string => {
  const contentLower = content.toLowerCase();
  const allText = contentLower + ' ' + tags.join(' ').toLowerCase();
  
  const categories = [
    { name: 'Work', keywords: ['work', 'project', 'meeting', 'deadline', 'task'] },
    { name: 'Personal', keywords: ['personal', 'life', 'family', 'friend', 'relationship'] },
    { name: 'Health', keywords: ['health', 'exercise', 'workout', 'fitness', 'diet', 'nutrition'] },
    { name: 'Mindfulness', keywords: ['mindful', 'meditation', 'calm', 'relax', 'peace', 'yoga'] },
    { name: 'Creativity', keywords: ['creative', 'art', 'music', 'write', 'design', 'idea'] },
    { name: 'Learning', keywords: ['learn', 'study', 'book', 'course', 'skill', 'knowledge'] },
    { name: 'Travel', keywords: ['travel', 'trip', 'journey', 'vacation', 'explore'] },
    { name: 'Food', keywords: ['food', 'recipe', 'cook', 'meal', 'restaurant', 'ingredient'] },
    { name: 'Technology', keywords: ['tech', 'code', 'program', 'app', 'software', 'computer'] },
    { name: 'Finance', keywords: ['money', 'finance', 'budget', 'invest', 'expense', 'saving'] }
  ];
  
  for (const category of categories) {
    if (category.keywords.some(keyword => allText.includes(keyword))) {
      return category.name;
    }
  }
  
  return 'Uncategorized';
};

// Get recommendations based on mood from Supabase
export const getRecommendationsForMood = async (mood: string) => {
  try {
    // Get notes that match the mood via category (simple mapping)
    const moodToCategories: Record<string, string[]> = {
      'happy': ['Creativity', 'Personal', 'Travel'],
      'calm': ['Mindfulness', 'Health', 'Personal'],
      'energetic': ['Health', 'Work', 'Travel'],
      'focused': ['Work', 'Learning', 'Technology'],
      'creative': ['Creativity', 'Learning', 'Food'],
      'reflective': ['Mindfulness', 'Personal', 'Learning']
    };
    
    const relevantCategories = moodToCategories[mood] || ['Uncategorized'];
    
    // Get notes related to mood
    const { data: noteData, error: noteError } = await supabase
      .from('notes')
      .select('*')
      .in('category', relevantCategories)
      .limit(4);
    
    if (noteError) {
      console.error('Error fetching mood-related notes:', noteError);
      toast("Failed to fetch mood recommendations");
    }

    // Map the note data to include createdAt
    const mappedNotes = noteData?.map(note => ({
      id: note.id,
      title: note.title,
      content: note.content,
      category: note.category || 'Uncategorized',
      tags: note.tags || [],
      createdAt: note.created_at
    })) || [];
    
    // Get web resources related to mood
    const { data: resourceData, error: resourceError } = await supabase
      .from('recommendations')
      .select('*')
      .eq('mood', mood)
      .limit(4);
    
    if (resourceError) {
      console.error('Error fetching mood resources:', resourceError);
      toast("Failed to fetch mood resources");
    }
    
    return {
      notes: mappedNotes,
      resources: resourceData || []
    };
  } catch (error) {
    console.error('Error in getRecommendationsForMood:', error);
    toast("Failed to fetch mood recommendations");
    return { notes: [], resources: [] };
  }
};

// Mock function for AI categorization (in a real app, this would call an AI service)
export const analyzeNoteWithAI = async (
  content: string, 
  tags: string[]
): Promise<{ category: string; relatedTopics: string[] }> => {
  // This is a mock implementation. In a real app, you would call an AI service
  return new Promise(resolve => {
    setTimeout(() => {
      const category = categorizeNote(content, tags);
      const relatedTopics = tags.slice(0, 3); // Just use some of the tags as related topics
      resolve({ category, relatedTopics });
    }, 500);
  });
};
