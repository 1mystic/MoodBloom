let currentView = 'home';
let currentMood = 'Playful';
let notes = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', async () => {
    await loadNotes();
    showView('home');
});

// View Management
function showView(viewName) {
    document.querySelectorAll('.view').forEach(view => {
        view.style.display = 'none';
    });
    document.getElementById(viewName + 'View').style.display = 'block';
    
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.classList.remove('active');
    });
    event.target.classList.add('active');
    
    currentView = viewName;
    updateView();
}

async function loadNotes() {
    try {
        const response = await fetch('/api/notes');
        notes = await response.json();
        updateView();
    } catch (error) {
        console.error('Error loading notes:', error);
    }
}

function updateView() {
    switch (currentView) {
        case 'home':
            displayNotes(notes.filter(note => note.mood === currentMood));
            break;
        case 'search':
            const query = document.getElementById('searchInput').value.toLowerCase();
            const filteredNotes = notes.filter(note => 
                note.title.toLowerCase().includes(query) ||
                note.content.toLowerCase().includes(query) ||
                note.tags.some(tag => tag.toLowerCase().includes(query))
            );
            displayNotes(filteredNotes, 'searchResults');
            break;
        case 'pinned':
            displayNotes(notes.filter(note => note.is_pinned));
            break;
    }
}

function displayNotes(notesToShow, containerId = 'notesGrid') {
    const container = document.getElementById(containerId);
    container.innerHTML = notesToShow.map(note => `
        <div class="note-card">
            <div class="note-header">
                <h3>${escapeHtml(note.title)}</h3>
                <button onclick="togglePin(${note.id})" class="pin-btn">
                    <span class="material-icons">${note.is_pinned ? 'push_pin' : 'push_pin_outlined'}</span>
                </button>
            </div>
            <div class="note-content">${formatContent(note.content)}</div>
            <div class="note-tags">
                ${note.tags.map(tag => `<span class="tag">${escapeHtml(tag)}</span>`).join('')}
            </div>
        </div>
    `).join('');
}

// Note Management
function showAddNoteModal() {
    document.getElementById('addNoteModal').style.display = 'flex';
}

function hideAddNoteModal() {
    document.getElementById('addNoteModal').style.display = 'none';
}

async function addNote() {
    const title = document.getElementById('noteTitle').value;
    const content = document.getElementById('noteContent').value;
    const tags = document.getElementById('noteTags').value;

    try {
        // First, analyze the mood
        const moodResponse = await fetch('/api/analyze_mood', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ content })
        });
        const moodData = await moodResponse.json();

        // Then create the note
        const response = await fetch('/api/notes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title,
                content,
                tags,
                mood: moodData.mood
            })
        });

        if (response.ok) {
            await loadNotes();
            hideAddNoteModal();
            document.getElementById('noteTitle').value = '';
            document.getElementById('noteContent').value = '';
            document.getElementById('noteTags').value = '';
        }
    } catch (error) {
        console.error('Error adding note:', error);
    }
}

// Utility Functions
function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function formatContent(content) {
    // Escape HTML first
    content = escapeHtml(content);
    
    // Format code blocks
    content = content.replace(/```(\w+)?\n([\s\S]*?)\n```/g, 
        '<pre class="code-block"><code>$2</code></pre>');
    
    // Format inline code
    content = content.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // Format LaTeX
    content = content.replace(/\$(.*?)\$/g, '<span class="math">$1</span>');
    
    // Convert URLs to links
    content = content.replace(
        /(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/g, 
        '<a href="$1" target="_blank">$1</a>'
    );
    
    return content;
}

// Event Listeners
document.getElementById('searchInput')?.addEventListener('input', () => {
    if (currentView === 'search') {
        updateView();
    }
});