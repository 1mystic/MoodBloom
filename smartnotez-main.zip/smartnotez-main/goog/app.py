import os
import json
from flask import Flask, request, jsonify, session, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import datetime
import random # For simulating AI mood picking

# --- App Configuration ---
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_very_secret_key_here' # Change this!
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'instance', 'notes.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# --- Database Models ---
tags = db.Table('tags',
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'), primary_key=True),
    db.Column('note_id', db.Integer, db.ForeignKey('note.id'), primary_key=True)
)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    notes = db.relationship('Note', backref='author', lazy=True, cascade="all, delete-orphan")
    groups = db.relationship('Group', backref='owner', lazy=True, cascade="all, delete-orphan")
    tags = db.relationship('Tag', backref='owner', lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False, default="Untitled")
    content = db.Column(db.Text, nullable=False, default="")
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    is_pinned = db.Column(db.Boolean, default=False, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    group_id = db.Column(db.Integer, db.ForeignKey('group.id'), nullable=True)
    parent_note_id = db.Column(db.Integer, db.ForeignKey('note.id'), nullable=True) # For sub-notes
    children_notes = db.relationship('Note', backref=db.backref('parent_note', remote_side=[id]), lazy='dynamic', cascade="all, delete-orphan")
    tags = db.relationship('Tag', secondary=tags, lazy='subquery',
                           backref=db.backref('notes', lazy=True))

    # Basic mood simulation based on keywords - replace with actual NLP later
    @property
    def mood(self):
        content_lower = (self.title + self.content).lower()
        if any(word in content_lower for word in ["play", "fun", "game", "happy", "joke", "light"]):
            return "playful"
        if any(word in content_lower for word in ["work", "task", "project", "meeting", "urgent"]):
            return "focused"
        if any(word in content_lower for word in ["idea", "brainstorm", "creative", "new"]):
            return "creative"
        return "neutral" # Default mood

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'is_pinned': self.is_pinned,
            'user_id': self.user_id,
            'group_id': self.group_id,
            'parent_note_id': self.parent_note_id,
            'tags': [tag.to_dict() for tag in self.tags],
            'mood': self.mood, # Add simulated mood
            'has_children': self.children_notes.count() > 0
        }

class Group(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    notes = db.relationship('Note', backref='group', lazy='dynamic')

    def to_dict(self):
        return {'id': self.id, 'name': self.name, 'user_id': self.user_id}

class Tag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    # Add unique constraint per user
    __table_args__ = (db.UniqueConstraint('name', 'user_id', name='_user_tag_uc'),)

    def to_dict(self):
        return {'id': self.id, 'name': self.name}

# --- Helper Function ---
def get_current_user():
    if 'user_id' in session:
        return User.query.get(session['user_id'])
    return None

# --- Routes ---
@app.route('/')
def index():
    # Serve the main HTML page which contains the Vue app
    return render_template('index.html')

# --- API Routes ---

# Authentication
@app.route('/api/auth/status', methods=['GET'])
def auth_status():
    user = get_current_user()
    if user:
        return jsonify({'logged_in': True, 'user': {'id': user.id, 'username': user.username}}), 200
    return jsonify({'logged_in': False}), 200

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({"message": "Username and password required"}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({"message": "Username already exists"}), 409

    user = User(username=username)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    # Automatically log in and create first note
    session['user_id'] = user.id
    session.permanent = True # Or use Flask-Login for better session management

    # Create the first welcome note
    first_note = Note(
        title="Welcome to Your Notes!",
        content="This is your first note. Feel free to edit or delete it.\n\nYou can:\n*   Create new notes\n*   Pin important ones\n*   Organize with groups and tags\n*   Add sub-notes\n*   Include links like [Google](https://google.com)\n*   Format code:\n```python\nprint('Hello, World!')\n```\n*   Even use LaTeX (requires frontend library):\n  `$E = mc^2$`",
        user_id=user.id
    )
    db.session.add(first_note)
    db.session.commit()

    return jsonify({'logged_in': True, 'user': {'id': user.id, 'username': user.username}, 'message': 'Registration successful'}), 201

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    user = User.query.filter_by(username=username).first()

    if user and user.check_password(password):
        session['user_id'] = user.id
        session.permanent = True # Remember user across browser sessions
        return jsonify({'logged_in': True, 'user': {'id': user.id, 'username': user.username}}), 200
    return jsonify({"message": "Invalid credentials"}), 401

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify({"message": "Logged out successfully"}), 200

# Notes CRUD and Features
@app.route('/api/notes', methods=['GET'])
def get_notes():
    user = get_current_user()
    if not user: return jsonify({"message": "Authentication required"}), 401

    query = Note.query.filter_by(user_id=user.id)

    # Filtering parameters
    search = request.args.get('search')
    mood = request.args.get('mood') # For mood-based fetching
    pinned = request.args.get('pinned') # 'true' or 'false'
    group_id = request.args.get('group_id')
    parent_id = request.args.get('parent_id', 'root') # 'root' fetches top-level notes

    if search:
        search_term = f"%{search}%"
        query = query.filter(Note.title.ilike(search_term) | Note.content.ilike(search_term))

    if mood:
         # This relies on the @property mood. For large datasets, this is inefficient.
         # A better approach would be pre-calculating/storing mood or using FTS with mood keywords.
        all_notes = query.all()
        filtered_notes = [note for note in all_notes if note.mood == mood]
        return jsonify([note.to_dict() for note in filtered_notes]), 200

    if pinned is not None:
        query = query.filter(Note.is_pinned == (pinned.lower() == 'true'))

    if group_id:
        try:
            query = query.filter(Note.group_id == int(group_id))
        except ValueError:
            pass # Ignore invalid group_id

    if parent_id == 'root':
         query = query.filter(Note.parent_note_id == None)
    elif parent_id:
        try:
            query = query.filter(Note.parent_note_id == int(parent_id))
        except ValueError:
            pass # Ignore invalid parent_id

    notes = query.order_by(Note.is_pinned.desc(), Note.updated_at.desc()).all()
    return jsonify([note.to_dict() for note in notes]), 200


@app.route('/api/notes', methods=['POST'])
def create_note():
    user = get_current_user()
    if not user: return jsonify({"message": "Authentication required"}), 401

    data = request.get_json() or {}
    # Sensible defaults if data is missing
    title = data.get('title', 'Untitled Note')
    content = data.get('content', '')
    parent_note_id = data.get('parent_note_id') # For creating sub-notes
    group_id = data.get('group_id')

    note = Note(
        title=title,
        content=content,
        user_id=user.id,
        parent_note_id=parent_note_id,
        group_id=group_id
    )
    db.session.add(note)
    db.session.commit()
    return jsonify(note.to_dict()), 201

@app.route('/api/notes/<int:note_id>', methods=['PUT'])
def update_note(note_id):
    user = get_current_user()
    if not user: return jsonify({"message": "Authentication required"}), 401

    note = Note.query.get_or_404(note_id)
    if note.user_id != user.id: return jsonify({"message": "Forbidden"}), 403

    data = request.get_json()
    if 'title' in data: note.title = data['title']
    if 'content' in data: note.content = data['content']
    if 'is_pinned' in data: note.is_pinned = data['is_pinned']
    if 'group_id' in data: note.group_id = data['group_id'] # Allows changing/removing group
    # Potentially add logic to update parent_note_id if needed (moving notes)

    # Tag Management within update
    if 'tags' in data: # Expecting a list of tag names [{'name': 'tag1'}, {'name': 'tag2'}] or similar
        current_tags = {tag.name for tag in note.tags}
        new_tag_names = {tag_data['name'] for tag_data in data['tags'] if isinstance(tag_data, dict) and 'name' in tag_data}

        # Remove tags not in the new list
        for tag in list(note.tags):
             if tag.name not in new_tag_names:
                 note.tags.remove(tag)

        # Add new tags
        for tag_name in new_tag_names:
            if tag_name not in current_tags:
                tag = Tag.query.filter_by(user_id=user.id, name=tag_name).first()
                if not tag: # Create tag if it doesn't exist for the user
                    tag = Tag(name=tag_name, user_id=user.id)
                    db.session.add(tag)
                    # Need intermediate commit or flush to get tag.id if relationship relies on it?
                    # For many-to-many, adding to the relationship collection handles it.
                if tag not in note.tags:
                     note.tags.append(tag)

    note.updated_at = datetime.datetime.utcnow() # Manually update timestamp if needed, SQLAlchemy might handle it
    db.session.commit()
    return jsonify(note.to_dict()), 200

@app.route('/api/notes/<int:note_id>', methods=['DELETE'])
def delete_note(note_id):
    user = get_current_user()
    if not user: return jsonify({"message": "Authentication required"}), 401

    note = Note.query.get_or_404(note_id)
    if note.user_id != user.id: return jsonify({"message": "Forbidden"}), 403

    # Recursively delete children? SQLAlchemy cascade might handle this if set correctly.
    # Or implement manual recursive delete if cascade isn't sufficient.
    db.session.delete(note)
    db.session.commit()
    return jsonify({"message": "Note deleted"}), 200


# Groups
@app.route('/api/groups', methods=['GET'])
def get_groups():
    user = get_current_user()
    if not user: return jsonify({"message": "Authentication required"}), 401
    groups = Group.query.filter_by(user_id=user.id).order_by(Group.name).all()
    return jsonify([group.to_dict() for group in groups]), 200

@app.route('/api/groups', methods=['POST'])
def create_group():
    user = get_current_user()
    if not user: return jsonify({"message": "Authentication required"}), 401
    data = request.get_json()
    name = data.get('name')
    if not name: return jsonify({"message": "Group name required"}), 400
    # Optional: Check if group name already exists for this user
    existing = Group.query.filter_by(user_id=user.id, name=name).first()
    if existing: return jsonify({"message": "Group name already exists"}), 409

    group = Group(name=name, user_id=user.id)
    db.session.add(group)
    db.session.commit()
    return jsonify(group.to_dict()), 201

# Tags (Basic - more specific tag management could be added)
@app.route('/api/tags', methods=['GET'])
def get_tags():
    user = get_current_user()
    if not user: return jsonify({"message": "Authentication required"}), 401
    tags = Tag.query.filter_by(user_id=user.id).order_by(Tag.name).all()
    return jsonify([tag.to_dict() for tag in tags]), 200


# --- Database Initialization ---
with app.app_context():
    # Create instance folder if it doesn't exist
    instance_path = os.path.join(basedir, 'instance')
    if not os.path.exists(instance_path):
        os.makedirs(instance_path)
    db.create_all() # Creates tables if they don't exist

# --- Run ---
if __name__ == '__main__':
    app.run(debug=True) # debug=True for development, False for production