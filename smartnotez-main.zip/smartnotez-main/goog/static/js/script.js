const { createApp } = Vue;

// Simple Debounce Function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func.apply(this, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}


createApp({
    compilerOptions: {
        delimiters: ['[[', ']]'] // <--- Add this configuration
    },
    data() {
        return {
            auth: {
                loggedIn: false,
                user: null,
                username: '',
                password: '',
                mode: 'login', // 'login' or 'register'
                error: null
            },
            notes: [], // Current list of notes being displayed
            allNotesCache: {}, // Cache fetched notes by ID for quick lookups (e.g., parent titles)
            groups: [],
            tags: [], // All tags for the user (for suggestions maybe)
            currentView: 'home', // 'home', 'search', 'groups', 'pinned', etc.
            selectedGroupId: null, // For filtering in groups view
            searchTerm: '',
            currentMood: 'playful', // Default mood for home page
            isLoading: false,
            showEditor: false,
            showViewer: false,
            editor: { // Data for the note editor modal
                isNew: true,
                note: { // Holds note data being edited/created
                    id: null,
                    title: '',
                    content: '',
                    is_pinned: false,
                    group_id: null,
                    parent_note_id: null,
                    tags: [] // Store tags as array of objects {id, name}
                },
                tagsInput: '', // Raw comma-separated input from user
                error: null
            },
            viewer: { // Data for the note viewer modal
                 note: null,
                 subNotes: [],
                 subNotesLoaded: false,
            },
            newGroupName: '',
            searchTimeout: null, // For debouncing search
        };
    },
    computed: {
        selectedGroupName() {
            if (this.selectedGroupId === null) return 'Uncategorized';
            const group = this.groups.find(g => g.id === this.selectedGroupId);
            return group ? group.name : 'Selected Group';
        }
    },
    methods: {
        // --- API Interaction ---
        async apiCall(endpoint, method = 'GET', body = null) {
            this.isLoading = true; // Show loading indicator
            this.auth.error = null; // Clear previous errors
            this.editor.error = null;

            const options = {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    // Add other headers like CSRF if needed
                },
            };
            if (body) {
                options.body = JSON.stringify(body);
            }

            try {
                const response = await fetch(endpoint, options);
                 const data = await response.json(); // Attempt to parse JSON regardless of status

                if (!response.ok) {
                    // Handle specific errors
                    if (response.status === 401) { // Unauthorized
                        console.warn("Unauthorized access, redirecting to login.");
                        this.auth.loggedIn = false;
                         this.auth.user = null;
                        this.auth.error = data.message || 'Authentication failed. Please login again.';
                    } else {
                        console.error(`API Error (${response.status}):`, data.message || response.statusText);
                        // Display error to the user appropriately
                         if (this.showEditor) this.editor.error = data.message || `Error: ${response.statusText}`;
                         else this.auth.error = data.message || `Error: ${response.statusText}`; // General error display
                    }
                    return null; // Indicate failure
                }
                return data; // Return successful data
            } catch (error) {
                console.error("Network or JSON parsing error:", error);
                const errorMsg = "Network error or failed to process server response.";
                if (this.showEditor) this.editor.error = errorMsg;
                else this.auth.error = errorMsg; // General error display
                return null; // Indicate failure
            } finally {
                 // Delay hiding loader slightly to avoid flashing
                 setTimeout(() => { this.isLoading = false; }, 200);
            }
        },

        // --- Authentication ---
        async checkAuthStatus() {
            const data = await this.apiCall('/api/auth/status');
            if (data) {
                this.auth.loggedIn = data.logged_in;
                this.auth.user = data.user || null;
                if (data.logged_in) {
                    // If logged in, fetch initial data for home view
                    this.setView('home'); // Go to home view
                    this.fetchGroups(); // Fetch groups for editor dropdown
                    this.fetchTags(); // Fetch all user tags
                }
            } else {
                this.auth.loggedIn = false;
                this.auth.user = null;
            }
        },
        async login() {
            const data = await this.apiCall('/api/auth/login', 'POST', {
                username: this.auth.username,
                password: this.auth.password
            });
            if (data && data.logged_in) {
                this.auth.loggedIn = true;
                this.auth.user = data.user;
                this.auth.password = ''; // Clear password field
                this.auth.error = null;
                // Fetch initial data after login
                this.setView('home');
                this.fetchGroups();
                this.fetchTags();
            } else {
                 this.auth.password = ''; // Clear password on failure too
                // Error message is set by apiCall
            }
        },
         async register() {
            const data = await this.apiCall('/api/auth/register', 'POST', {
                username: this.auth.username,
                password: this.auth.password
            });
            if (data && data.logged_in) {
                this.auth.loggedIn = true;
                this.auth.user = data.user;
                this.auth.password = '';
                this.auth.error = null;
                 // Backend creates the first note, now fetch data
                this.setView('home'); // Should show the welcome note
                this.fetchGroups();
                this.fetchTags();
            } else {
                this.auth.password = '';
                 // Error message set by apiCall
            }
        },
        async logout() {
            const data = await this.apiCall('/api/auth/logout', 'POST');
            if (data) {
                 this.auth.loggedIn = false;
                 this.auth.user = null;
                 this.notes = [];
                 this.groups = [];
                 this.tags = [];
                 this.currentView = 'home'; // Or redirect to a logged-out page
                 this.auth.username = '';
                 this.auth.password = '';
                 this.auth.mode = 'login';
            }
             // No specific error handling needed usually for logout unless server fails
        },

        // --- View Management & Data Fetching ---
        setView(view) {
            this.currentView = view;
            this.searchTerm = ''; // Reset search term when changing views
            this.notes = []; // Clear notes before fetching new ones
            this.selectedGroupId = null; // Reset group selection unless navigating within groups view
            this.fetchNotesForCurrentView();
        },

        fetchNotesForCurrentView() {
            let params = {};
            switch (this.currentView) {
                case 'home':
                     // Fetch notes matching the currentMood, potentially filtered by quick search
                     params.mood = this.currentMood;
                     if (this.searchTerm) {
                         params.search = this.searchTerm;
                         delete params.mood; // Search overrides mood on home? Or combine? Let's override for now.
                     }
                    break;
                case 'search':
                    if (!this.searchTerm) {
                        this.notes = []; // Clear results if search is empty
                        return;
                    }
                    params.search = this.searchTerm;
                    break;
                case 'groups':
                    // Fetch notes for the selected group or uncategorized
                    if (this.selectedGroupId !== null) {
                        params.group_id = this.selectedGroupId;
                    } else {
                         // How to fetch "uncategorized"? Need API support or filter client-side?
                         // Let's assume API handles group_id=null or default filter is no group
                         // For now, let's rely on filtering notes without group_id on client if needed,
                         // or better, fetch all and filter *or* ideally backend handles `group_id=null`
                        // Assuming backend handles `group_id=<id>` and no group_id fetches all top-level
                        // We need a specific way to fetch *only* uncategorized. Add param?
                        // Quick fix: fetch all and filter client-side for 'uncategorized'
                        // Or modify backend: add `?group_id=null` query param interpretation
                        // Let's assume backend doesn't support `group_id=null` yet, so fetch all and filter.
                        // **Correction**: Backend `/api/notes` *should* be able to filter by group_id,
                        // including potentially null if designed so. Let's assume it can.
                        params.group_id = this.selectedGroupId; // null will be sent if selectedGroupId is null
                    }
                    break;
                case 'pinned':
                    params.pinned = 'true';
                    break;
                default:
                    // Fetch top-level notes by default if view logic is missing
                    params.parent_id = 'root';
                    break;
            }
             // Fetch only top-level notes by default unless viewing subnotes
             if (!params.parent_id && this.currentView !== 'viewer_subnotes') { // Check if we are viewing subnotes
                 params.parent_id = 'root';
             }

            this.fetchNotes(params);
        },

        async fetchNotes(params = {}) {
            const queryString = new URLSearchParams(params).toString();
            const data = await this.apiCall(`/api/notes?${queryString}`);
            if (data) {
                this.notes = data;
                // Update cache
                data.forEach(note => { this.allNotesCache[note.id] = note; });
            } else {
                this.notes = []; // Clear notes on fetch error
            }
        },

        async fetchGroups() {
            const data = await this.apiCall('/api/groups');
            if (data) {
                this.groups = data;
            }
        },

        async fetchTags() {
             const data = await this.apiCall('/api/tags');
            if (data) {
                this.tags = data;
            }
        },

         // Debounced search function
        debouncedSearch: debounce(function() {
            // In search view, always trigger fetch. In home view, trigger fetch.
            if (this.currentView === 'search' || this.currentView === 'home') {
                 this.fetchNotesForCurrentView();
            }
        }, 300), // 300ms delay


        // --- Note Actions ---
        selectNote(note) {
            // Open the Note Viewer modal
            this.viewer.note = { ...note }; // Copy note data to viewer
            this.viewer.subNotes = []; // Reset subnotes
            this.viewer.subNotesLoaded = false;
            this.showViewer = true;
            // Optionally pre-load sub-notes if needed immediately
            // if(note.has_children) this.loadSubNotes(note.id);
        },

        viewSubNote(subNote) {
            // Close current viewer if open, then open new viewer for subnote
            this.closeViewer();
            // Use a slight delay to ensure the DOM updates if needed
            this.$nextTick(() => {
                this.selectNote(subNote); // Select the sub-note to view it
            });
        },

        async loadSubNotes(parentId) {
            if (!this.viewer.note || this.viewer.note.id !== parentId) return; // Safety check

            this.isLoading = true; // Use main loader or a specific sub-note loader
            const data = await this.apiCall(`/api/notes?parent_id=${parentId}`);
            this.isLoading = false;

            if (data) {
                this.viewer.subNotes = data;
                this.viewer.subNotesLoaded = true;
                 // Update cache
                 data.forEach(note => { this.allNotesCache[note.id] = note; });
            } else {
                // Handle error - maybe show message in the viewer
                console.error("Failed to load sub-notes");
            }
        },

         openNewNoteEditor(parentNoteId = null) {
            this.editor = {
                isNew: true,
                note: {
                    id: null,
                    title: '',
                    content: '',
                    is_pinned: false,
                    group_id: this.selectedGroupId, // Pre-select current group if in groups view
                    parent_note_id: parentNoteId, // Set parent ID if provided
                    tags: []
                },
                 tagsInput: '',
                error: null
            };
            this.showEditor = true;
        },

        openEditModal(note) {
             // Close viewer if open
             this.closeViewer();

             this.$nextTick(async () => {
                 // Fetch the full note data again in case content is large or details changed
                 // Or just use the potentially stale data from the list/viewer for speed
                 const freshNoteData = await this.apiCall(`/api/notes/${note.id}`); // Optional fetch
                 const noteToEdit = freshNoteData || { ...note }; // Use fresh data or fallback

                 this.editor = {
                     isNew: false,
                     note: { // Ensure all fields are present
                         id: noteToEdit.id,
                         title: noteToEdit.title,
                         content: noteToEdit.content,
                         is_pinned: noteToEdit.is_pinned,
                         group_id: noteToEdit.group_id,
                         parent_note_id: noteToEdit.parent_note_id,
                         tags: noteToEdit.tags || [] // Ensure tags array exists
                     },
                     tagsInput: (noteToEdit.tags || []).map(t => t.name).join(', '), // Populate tags input
                     error: null
                 };
                 this.showEditor = true;
             });
        },

        closeEditor() {
            this.showEditor = false;
            // Optionally reset editor state if needed
        },
         closeViewer() {
            this.showViewer = false;
            this.viewer.note = null;
            this.viewer.subNotes = [];
            this.viewer.subNotesLoaded = false;
        },

        parseTagsInput() {
            // Convert comma-separated string into array of tag objects for saving
            return this.editor.tagsInput
                       .split(',')
                       .map(name => name.trim())
                       .filter(name => name !== '')
                       .map(name => ({ name: name })); // Send as [{name: 'tag1'}, {name: 'tag2'}]
        },

        async saveNote() {
            this.editor.error = null;
            if (!this.editor.note.title?.trim()) {
                this.editor.error = "Title cannot be empty.";
                return;
            }

            const noteData = { ...this.editor.note };
            noteData.tags = this.parseTagsInput(); // Process tags before sending

            let savedNote;
            if (this.editor.isNew) {
                // Create new note
                savedNote = await this.apiCall('/api/notes', 'POST', noteData);
            } else {
                // Update existing note
                 savedNote = await this.apiCall(`/api/notes/${noteData.id}`, 'PUT', noteData);
            }

            if (savedNote) {
                this.closeEditor();
                // Update the notes list intelligently
                // Could refetch the entire list or smartly update/add the item
                this.fetchNotesForCurrentView(); // Simplest way is to refetch
                 this.fetchTags(); // Refetch tags in case new ones were added
                this.allNotesCache[savedNote.id] = savedNote; // Update cache
            }
            // If save failed, error message is shown by apiCall
        },

        confirmDeleteNote(noteId) {
            if (confirm('Are you sure you want to delete this note? This action cannot be undone.')) {
                this.deleteNote(noteId);
            }
        },

        async deleteNote(noteId) {
            // Close viewer or editor if the deleted note is open
             if (this.showViewer && this.viewer.note?.id === noteId) this.closeViewer();
             if (this.showEditor && this.editor.note?.id === noteId) this.closeEditor();

            const result = await this.apiCall(`/api/notes/${noteId}`, 'DELETE');
            if (result) {
                // Remove note from the current list and cache
                 this.notes = this.notes.filter(note => note.id !== noteId);
                 delete this.allNotesCache[noteId];
                 // Optional: show success message
            }
        },

        async togglePin(note) {
             const updatedNoteData = { ...note, is_pinned: !note.is_pinned };

             // Prevent sending full content if not needed, just send required fields
             const payload = {
                 is_pinned: updatedNoteData.is_pinned,
                 // Include other fields if the PUT endpoint expects them or needs context
                 // title: updatedNoteData.title, // Probably not needed just for pinning
             };


            const result = await this.apiCall(`/api/notes/${note.id}`, 'PUT', payload);

             if (result) {
                 // Update the note in the local list and cache
                 const index = this.notes.findIndex(n => n.id === note.id);
                 if (index !== -1) {
                     this.notes[index].is_pinned = result.is_pinned;
                     this.notes[index].updated_at = result.updated_at; // Update timestamp
                 }
                 if (this.allNotesCache[note.id]) {
                     this.allNotesCache[note.id].is_pinned = result.is_pinned;
                      this.allNotesCache[note.id].updated_at = result.updated_at;
                 }
                 // If in pinned view and unpinning, refetch
                 if (this.currentView === 'pinned' && !result.is_pinned) {
                    this.fetchNotesForCurrentView();
                 }
                  // If viewer was open for this note, update it
                 if (this.showViewer && this.viewer.note?.id === note.id) {
                     this.viewer.note.is_pinned = result.is_pinned;
                      this.viewer.note.updated_at = result.updated_at;
                 }
            }
        },

        // --- Group Actions ---
        selectGroup(groupId) {
            this.selectedGroupId = groupId;
            this.fetchNotesForCurrentView(); // Refetch notes for the selected group
        },

        async createGroup() {
            if (!this.newGroupName.trim()) return;
            const result = await this.apiCall('/api/groups', 'POST', { name: this.newGroupName });
            if (result) {
                this.groups.push(result);
                this.newGroupName = ''; // Clear input
                this.selectedGroupId = result.id; // Select the newly created group
                this.fetchNotesForCurrentView(); // Fetch notes (likely empty) for the new group
            }
        },

        // --- Formatting & Rendering ---
         renderFormattedContent(content) {
            if (!content) return '';

             // 1. Use Marked.js for Markdown (links, basic formatting, code blocks)
             // Configure marked to use highlight.js for code blocks
             marked.setOptions({
                 highlight: function(code, lang) {
                     const language = hljs.getLanguage(lang) ? lang : 'plaintext';
                     return hljs.highlight(code, { language }).value;
                 },
                 breaks: true, // Convert single newlines to <br>
                 gfm: true // Enable GitHub Flavored Markdown
             });
             let html = marked.parse(content);

            // 2. Use KaTeX for LaTeX rendering
            // Wrap this in a try-catch as KaTeX can throw errors on invalid syntax
            try {
                // Use KaTeX auto-render extension
                 // Temporary div to render into
                 const tempDiv = document.createElement('div');
                 tempDiv.innerHTML = html;
                 renderMathInElement(tempDiv, {
                     delimiters: [
                         {left: "$$", right: "$$", display: true}, // Display math
                         {left: "$", right: "$", display: false},  // Inline math
                         {left: "\\(", right: "\\)", display: false},
                         {left: "\\[", right: "\\]", display: true}
                     ],
                     throwOnError: false // Don't halt rendering on error
                 });
                 html = tempDiv.innerHTML;
            } catch (e) {
                console.error("KaTeX rendering error:", e);
            }

            // 3. Sanitize HTML (IMPORTANT FOR SECURITY if content comes from untrusted sources)
            // For this app, user's own content is less risky, but still good practice.
            // Use a library like DOMPurify if available, otherwise basic sanitization might be needed.
            // Since we are generating HTML from known sources (Marked, KaTeX), risk is lower.
            // Be cautious if allowing arbitrary HTML input.

            return html;
        },

        // --- Helpers ---
        formatDate(dateString) {
            if (!dateString) return '';
            const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
            return new Date(dateString).toLocaleDateString(undefined, options);
        },
        getGroupName(groupId) {
            const group = this.groups.find(g => g.id === groupId);
            return group ? group.name : 'Unknown Group';
        },
         getParentNoteTitle(noteId) {
             // Look up parent note title from cache
             const parentNote = this.allNotesCache[noteId];
             return parentNote ? parentNote.title : (noteId ? 'Loading...' : ''); // Indicate loading or missing
             // Could trigger a fetch if not in cache:
             // if (!parentNote && noteId) { this.fetchNoteById(noteId); return 'Loading...'; }
         },
         capitalize(value) {
             if (!value) return ''
             value = value.toString()
             return value.charAt(0).toUpperCase() + value.slice(1)
         }

    },
    mounted() {
        // Check authentication status when the app loads
        this.checkAuthStatus();

         // Add hljs to window for Marked.js if not already global (depends on how CDN loads it)
         window.hljs = hljs;
    },
     // --- Component Definition (for Note Card) ---
     components: {
         'note-card': {
             props: ['note'],
             template: `
                 <div class="note-card" :class="{ pinned: note.is_pinned }" @click="$emit('select', note)">
                     <button class="pin-button" @click.stop="$emit('pin', note)">
                         <i :class="note.is_pinned ? 'fas fa-thumbtack' : 'far fa-thumbtack'"></i>
                     </button>
                     <h4 class="note-title">{{ note.title }}</h4>
                     <!-- Basic preview, doesn't render markdown fully -->
                     <p class="note-preview">{{ truncate(note.content, 100) }}</p>
                     <div class="note-footer">
                         <span class="note-date">{{ formatDate(note.updated_at) }}</span>
                          <div class="note-tags">
                             <span v-for="tag in note.tags" :key="tag.id" class="tag-badge">{{ tag.name }}</span>
                         </div>
                         <button class="delete-button-card" @click.stop="$emit('delete', note.id)">
                             <i class="fas fa-trash-alt"></i>
                         </button>
                     </div>
                 </div>
             `,
             methods: {
                 truncate(text, length) {
                     if (!text) return '';
                     // Basic truncate, doesn't handle HTML/Markdown well
                     return text.length > length ? text.substring(0, length) + '...' : text;
                 },
                  formatDate(dateString) { // Make helper available in component
                     if (!dateString) return '';
                     const options = { year: 'numeric', month: 'short', day: 'numeric' };
                     return new Date(dateString).toLocaleDateString(undefined, options);
                 }
             }
         }
     }
}).mount('#app');