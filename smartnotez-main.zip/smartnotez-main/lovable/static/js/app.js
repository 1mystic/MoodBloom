// Component for displaying individual note cards
Vue.component('note-card', {
    props: ['note'],
    template: `
        <div class="note-card">
            <div class="note-card-header">
                <div class="note-card-title">{{ note.title }}</div>
                <i v-if="note.is_pinned" class="fa-solid fa-thumbtack pin-active"></i>
            </div>
            <div class="note-card-content" v-html="formatContent"></div>
            <div class="note-card-footer">
                <div class="note-card-tags">
                    <span v-for="tag in note.tags.slice(0, 2)" class="note-card-tag">
                        #{{ tag.name }}
                    </span>
                    <span v-if="note.tags.length > 2" class="note-card-tag">
                        +{{ note.tags.length - 2 }}
                    </span>
                </div>
                <div class="note-card-date">{{ formatDate(note.updated_at) }}</div>
            </div>
            <div v-if="note.has_children" class="has-subnotes">
                <i class="fa-solid fa-folder"></i>
            </div>
            <div class="note-card-menu">
                <div class="dropdown">
                    <button class="note-card-menu-btn" @click.stop="toggleMenu">
                        <i class="fa-solid fa-ellipsis-vertical"></i>
                    </button>
                    <div v-if="showMenu" class="note-card-menu-dropdown">
                        <button class="note-card-menu-item" @click.stop="edit">
                            <i class="fa-solid fa-pen"></i> Edit
                        </button>
                        <button class="note-card-menu-item" @click.stop="togglePin">
                            <i class="fa-solid" :class="note.is_pinned ? 'fa-thumbtack pin-active' : 'fa-thumbtack'"></i>
                            {{ note.is_pinned ? 'Unpin' : 'Pin' }}
                        </button>
                        <button class="note-card-menu-item" @click.stop="addSubNote">
                            <i class="fa-solid fa-plus"></i> Add Sub-note
                        </button>
                        <button class="note-card-menu-item delete" @click.stop="deleteNote">
                            <i class="fa-solid fa-trash"></i> Delete
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `,
    data() {
        return {
            showMenu: false
        };
    },
    computed: {
        formatContent() {
            // Simple preview of content - strip markdown, limit length
            let content = this.note.content || '';
            // Remove markdown syntax (very basic)
            content = content
                .replace(/[*#`_]/g, '')
                .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // Replace markdown links with just the text
                .replace(/!\[([^\]]+)\]\([^)]+\)/g, '[Image: $1]'); // Replace markdown images
            
            return content.length > 150 ? content.substring(0, 150) + '...' : content;
        }
    },
    methods: {
        formatDate(dateString) {
            const date = new Date(dateString);
            const now = new Date();
            const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            const noteDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            
            if (noteDate.getTime() === today.getTime()) {
                // Today - show time
                return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            } else if (now.getFullYear() === date.getFullYear()) {
                // This year - show month and day
                return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
            } else {
                // Different year - show year
                return date.toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' });
            }
        },
        toggleMenu(event) {
            event.stopPropagation();
            this.showMenu = !this.showMenu;
            // Close menu when clicking outside
            if (this.showMenu) {
                const closeOnOutsideClick = (e) => {
                    this.showMenu = false;
                    document.removeEventListener('click', closeOnOutsideClick);
                };
                setTimeout(() => {
                    document.addEventListener('click', closeOnOutsideClick);
                }, 0);
            }
        },
        edit() {
            this.$emit('edit', this.note);
        },
        deleteNote() {
            this.$emit('delete', this.note);
        },
        togglePin() {
            this.$emit('toggle-pin', this.note);
        },
        addSubNote() {
            this.$parent.createSubNote(this.note.id);
        }
    }
});

// Main Vue App
const app = Vue.createApp({
    data() {
        return {
            appReady: false,
            user: null,
            authMode: 'login',
            authForm: {
                username: '',
                password: ''
            },
            authError: null,
            notes: [],
            groups: [],
            tags: [],
            sidebarCollapsed: false,
            currentRoute: 'home',
            searchQuery: '',
            selectedGroup: null,
            selectedTag: null,
            currentMood: 'playful', // Default mood
            showNoteModal: false,
            editingNote: {
                title: '',
                content: '',
                is_pinned: false,
                group_id: null,
                parent_note_id: null,
                tags: []
            },
            newTagName: '',
            parentNoteForCreate: null,
            showCreateGroupModal: false,
            newGroupName: '',
            showDeleteModal: false,
            noteToDelete: null,
            toast: {
                show: false,
                message: '',
                type: 'info',
                timeout: null
            },
            // List of possible moods
            moods: ['playful', 'focused', 'creative', 'neutral']
        };
    },
    computed: {
        // Filter notes based on current mood for home view
        filteredNotes() {
            return this.notes.filter(note => note.mood === this.currentMood);
        },
        // Search results
        searchResults() {
            if (!this.searchQuery) return [];
            
            const query = this.searchQuery.toLowerCase();
            return this.notes.filter(note => {
                return note.title.toLowerCase().includes(query) || 
                       note.content.toLowerCase().includes(query) ||
                       note.tags.some(tag => tag.name.toLowerCase().includes(query));
            });
        },
        // Pinned notes
        pinnedNotes() {
            return this.notes.filter(note => note.is_pinned);
        },
        // Notes in selected group
        groupNotes() {
            return this.notes.filter(note => note.group_id === this.selectedGroup?.id);
        },
        // Notes with selected tag
        taggedNotes() {
            if (!this.selectedTag) return [];
            return this.notes.filter(note => 
                note.tags.some(tag => tag.id === this.selectedTag.id)
            );
        },
        // Sub-notes of current note being edited
        subNotes() {
            if (!this.editingNote.id) return [];
            return this.notes.filter(note => note.parent_note_id === this.editingNote.id);
        },
        // Icon for current mood
        moodIcon() {
            switch(this.currentMood) {
                case 'playful': return 'fa-face-laugh-beam';
                case 'focused': return 'fa-bullseye';
                case 'creative': return 'fa-lightbulb';
                default: return 'fa-face-smile';
            }
        },
        // Icon for toast notification
        toastIcon() {
            switch(this.toast.type) {
                case 'success': return 'fa-check';
                case 'error': return 'fa-exclamation-circle';
                default: return 'fa-info-circle';
            }
        }
    },
    watch: {
        currentRoute(newRoute, oldRoute) {
            // Reset search when navigating away from search page
            if (oldRoute === 'search') {
                this.searchQuery = '';
            }
        }
    },
    methods: {
        // API and data handling methods
        async checkAuthStatus() {
            try {
                const response = await fetch('http://127.0.0.1:5000/api/auth/status');
                const data = await response.json();
                
                if (data.logged_in) {
                    this.user = data.user;
                    await this.fetchNotes();
                    await this.fetchGroups();
                    await this.fetchTags();
                } else {
                    this.user = null;
                }
            } catch (error) {
                console.error('Error checking auth status:', error);
            }
            
            // Set app as ready after auth check
            this.appReady = true;
        },
        
        async handleAuth() {
            this.authError = null;
            const endpoint = this.authMode === 'login' ? 'http://127.0.0.1:5000/api/auth/login' : 'http://127.0.0.1:5000/api/auth/register';
            
            try {
                const response = await fetch(endpoint, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(this.authForm)
                });
                
                const data = await response.json();
                
                if (!response.ok) {
                    this.authError = data.message;
                    return;
                }
                
                this.user = data.user;
                await this.fetchNotes();
                await this.fetchGroups();
                await this.fetchTags();
                this.authForm = { username: '', password: '' };
                
                // Select random mood for first login
                if (this.authMode === 'register') {
                    this.currentMood = this.moods[Math.floor(Math.random() * this.moods.length)];
                }
            } catch (error) {
                console.error('Auth error:', error);
                this.authError = 'An error occurred during authentication';
            }
        },
        
        async logout() {
            try {
                await fetch('http://127.0.0.1:5000/api/auth/logout', { method: 'POST' });
                this.user = null;
                this.currentRoute = 'home';
            } catch (error) {
                console.error('Logout error:', error);
            }
        },
        
        async fetchNotes() {
            try {
                const response = await fetch('http://127.0.0.1:5000/api/notes');
                if (response.ok) {
                    const data = await response.json();
                    this.notes = data;
                }
            } catch (error) {
                console.error('Error fetching notes:', error);
                this.showToast('Error loading notes', 'error');
            }
        },
        
        async fetchGroups() {
            try {
                const response = await fetch('http://127.0.0.1:5000/api/groups');
                if (response.ok) {
                    this.groups = await response.json();
                }
            } catch (error) {
                console.error('Error fetching groups:', error);
            }
        },
        
        async fetchTags() {
            try {
                const response = await fetch('http://127.0.0.1:5000/api/tags');
                if (response.ok) {
                    this.tags = await response.json();
                }
            } catch (error) {
                console.error('Error fetching tags:', error);
            }
        },
        
        async saveNote() {
            // Make a copy to avoid mutating the state during update
            const noteToSave = JSON.parse(JSON.stringify(this.editingNote));
            
            try {
                let response;
                
                if (noteToSave.id) {
                    // Update existing note
                    response = await fetch(`http://127.0.0.1:5000/api/notes/${noteToSave.id}`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(noteToSave)
                    });
                } else {
                    // Create new note
                    response = await fetch('http://127.0.0.1:5000/api/notes', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(noteToSave)
                    });
                }
                
                if (response.ok) {
                    const savedNote = await response.json();
                    
                    // Update notes array
                    await this.fetchNotes();
                    await this.fetchTags(); // Tags might have changed
                    
                    this.closeNoteModal();
                    this.showToast(`Note ${noteToSave.id ? 'updated' : 'created'} successfully`, 'success');
                    
                    // If we were creating a sub-note, navigate back to parent
                    if (this.parentNoteForCreate && savedNote.parent_note_id) {
                        // Optionally reload the parent note for editing to see updated sub-notes
                        const parentNote = this.notes.find(note => note.id === savedNote.parent_note_id);
                        if (parentNote) {
                            this.editNote(parentNote);
                        }
                    }
                } else {
                    const error = await response.json();
                    throw new Error(error.message || 'Failed to save note');
                }
            } catch (error) {
                console.error('Error saving note:', error);
                this.showToast('Error saving note', 'error');
            }
        },
        
        async togglePin(note) {
            try {
                const updatedNote = { ...note, is_pinned: !note.is_pinned };
                
                const response = await fetch(`http://127.0.0.1:5000/api/notes/${note.id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ is_pinned: updatedNote.is_pinned })
                });
                
                if (response.ok) {
                    // Update local note
                    const index = this.notes.findIndex(n => n.id === note.id);
                    if (index !== -1) {
                        this.notes[index].is_pinned = updatedNote.is_pinned;
                    }
                    
                    // If editing this note, update there too
                    if (this.editingNote.id === note.id) {
                        this.editingNote.is_pinned = updatedNote.is_pinned;
                    }
                    
                    this.showToast(
                        updatedNote.is_pinned ? 'Note pinned successfully' : 'Note unpinned',
                        'success'
                    );
                }
            } catch (error) {
                console.error('Error toggling pin:', error);
                this.showToast('Error updating note', 'error');
            }
        },
        
        async deleteNote() {
            if (!this.noteToDelete) return;
            
            try {
                const response = await fetch(`http://127.0.0.1:5000/api/notes/${this.noteToDelete.id}`, {
                    method: 'DELETE'
                });
                
                if (response.ok) {
                    // Remove from notes array
                    this.notes = this.notes.filter(note => note.id !== this.noteToDelete.id);
                    // Also remove any sub-notes (they should be cascade deleted on server)
                    this.notes = this.notes.filter(note => note.parent_note_id !== this.noteToDelete.id);
                    
                    this.showDeleteModal = false;
                    this.noteToDelete = null;
                    this.closeNoteModal(); // Close edit modal if open
                    this.showToast('Note deleted successfully', 'success');
                }
            } catch (error) {
                console.error('Error deleting note:', error);
                this.showToast('Error deleting note', 'error');
            }
        },
        
        async createGroup() {
            if (!this.newGroupName.trim()) return;
            
            try {
                const response = await fetch('http://127.0.0.1:5000/api/groups', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ name: this.newGroupName.trim() })
                });
                
                if (response.ok) {
                    const newGroup = await response.json();
                    this.groups.push(newGroup);
                    this.newGroupName = '';
                    this.showCreateGroupModal = false;
                    this.showToast('Group created successfully', 'success');
                } else {
                    const error = await response.json();
                    throw new Error(error.message || 'Failed to create group');
                }
            } catch (error) {
                console.error('Error creating group:', error);
                this.showToast('Error creating group', 'error');
            }
        },
        
        // UI interaction methods
        createNote(parentId = null, groupId = null) {
            this.editingNote = {
                title: '',
                content: '',
                is_pinned: false,
                group_id: groupId,
                parent_note_id: parentId,
                tags: []
            };
            this.parentNoteForCreate = parentId ? this.notes.find(note => note.id === parentId) : null;
            this.showNoteModal = true;
        },
        
        createSubNote(parentId) {
            this.createNote(parentId);
        },
        
        editNote(note) {
            // Make a deep copy to avoid direct mutation
            this.editingNote = JSON.parse(JSON.stringify(note));
            if (!this.editingNote.tags) {
                this.editingNote.tags = [];
            }
            this.showNoteModal = true;
        },
        
        closeNoteModal() {
            this.showNoteModal = false;
            this.editingNote = {
                title: '',
                content: '',
                is_pinned: false,
                group_id: null,
                parent_note_id: null,
                tags: []
            };
            this.parentNoteForCreate = null;
            this.newTagName = '';
        },
        
        confirmDeleteNote(note) {
            this.noteToDelete = note;
            this.showDeleteModal = true;
        },
        
        addTag() {
            if (!this.newTagName.trim()) return;
            
            // Check if tag already exists on this note
            if (!this.editingNote.tags.some(tag => tag.name.toLowerCase() === this.newTagName.trim().toLowerCase())) {
                this.editingNote.tags.push({
                    name: this.newTagName.trim()
                });
            }
            
            this.newTagName = '';
        },
        
        removeTag(index) {
            this.editingNote.tags.splice(index, 1);
        },
        
        selectGroup(group) {
            this.selectedGroup = group;
            this.currentRoute = 'group-detail';
        },
        
        filterByTag(tag) {
            this.selectedTag = tag;
            this.currentRoute = 'tag-detail';
        },
        
        countNotesInGroup(groupId) {
            return this.notes.filter(note => note.group_id === groupId).length;
        },
        
        hasSubNotes(note) {
            if (!note) return false;
            return this.notes.some(n => n.parent_note_id === note.id);
        },
        
        showToast(message, type = 'info') {
            // Clear any existing toast timeout
            if (this.toast.timeout) {
                clearTimeout(this.toast.timeout);
            }
            
            // Set toast properties
            this.toast.message = message;
            this.toast.type = type;
            this.toast.show = true;
            
            // Hide toast after 3 seconds
            this.toast.timeout = setTimeout(() => {
                this.toast.show = false;
            }, 3000);
        },
        
        formatDate(dateString) {
            return new Date(dateString).toLocaleDateString(undefined, {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        },
        
        // Lifecycle
        async initApp() {
            // Change mood every day
            const dailyMoodSeed = new Date().toISOString().split('T')[0]; // Today's date YYYY-MM-DD
            const moodIndex = this.hashString(dailyMoodSeed) % this.moods.length;
            this.currentMood = this.moods[moodIndex];
            
            // Check auth status
            await this.checkAuthStatus();
        },
        
        // Helper method to generate a simple hash from a string
        hashString(str) {
            let hash = 0;
            for (let i = 0; i < str.length; i++) {
                hash = ((hash << 5) - hash) + str.charCodeAt(i);
                hash |= 0; // Convert to 32bit integer
            }
            return Math.abs(hash);
        }
    },
    mounted() {
        this.initApp();
        
        // Listen for escape key to close modals
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.showNoteModal = false;
                this.showCreateGroupModal = false;
                this.showDeleteModal = false;
            }
        });
    }
}).mount('#app');